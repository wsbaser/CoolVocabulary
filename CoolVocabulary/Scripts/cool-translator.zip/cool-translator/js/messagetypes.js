var MessageTypes = {};
MessageTypes.LoadInitializationData = "loadinitializationdata";
MessageTypes.SaveLangPair = "savelangpair";