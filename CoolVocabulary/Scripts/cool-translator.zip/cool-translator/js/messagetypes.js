var MessageTypes = {};
MessageTypes.LoadInitializationData = "loadinitializationdata";
MessageTypes.SaveLangPair = "savelangpair";
MessageTypes.InitSiteDialog = "initsitedialog";