/**
 * Created by wsbaser on 15.07.2015.
 */
/***** ExamProvider ***************************************************************************************************/
/*
 * Provides cards for word examination
 * */
function ExamProvider(store) {
    this.store = store;
}