/**
 * Created by wsbaser on 15.07.2015.
 */
/***** LearnProvider **************************************************************************************************/
/*
 * Provides cards for word learning
 * */
function LearnProvider(store) {
    this.store = store;
}
