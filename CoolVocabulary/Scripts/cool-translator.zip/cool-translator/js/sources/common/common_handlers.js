function show_dialog_for_content(el) {
    Dialog.show(el.textContent.trim());
    return false;
};
